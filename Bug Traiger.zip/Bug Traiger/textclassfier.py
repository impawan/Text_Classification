# -*- coding: utf-8 -*-
"""
Created on Sat Apr  7 21:56:45 2018

@author: ACER
"""


import pandas as pd
data = pd.read_csv('Bug_ReportFinal pipe splitted.csv',encoding = "ISO-8859-1") #text in column 2, classifier in column 1.
data = data.dropna(how='any',axis=0)
import numpy as np
numpy_array = data.as_matrix()
X = numpy_array[:,1]
Y = numpy_array[:,0]

from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split(
 X, Y, test_size=0.4, random_state=52)

from sklearn.feature_extraction.text import CountVectorizer

from sklearn.feature_extraction.text import TfidfTransformer

#different Model of ML

from sklearn.naive_bayes import MultinomialNB  

from sklearn.linear_model import SGDClassifier

from sklearn.pipeline import Pipeline
text_clf_NB = Pipeline([('vect', CountVectorizer(stop_words='english')),
 ('tfidf', TfidfTransformer()),
 ('clf', MultinomialNB()),
])


text_clf_NB = text_clf_NB.fit(X_train,Y_train)

predicted = text_clf_NB.predict(X_test)
accuracy = np.mean(predicted == Y_test)

print ("Accurcy for Naive Bayes:  ",accuracy)

text_clf_SVM = Pipeline([('vect', CountVectorizer(stop_words='english')),
 ('tfidf', TfidfTransformer()),
 ('clf', SGDClassifier()),
])



text_clf_SVM = text_clf_SVM.fit(X_train,Y_train)

predicted = text_clf_SVM.predict(X_test)
accuracy = np.mean(predicted == Y_test)

print ("Accurcy for SVM:  ",accuracy)


