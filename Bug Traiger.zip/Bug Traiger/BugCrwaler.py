# -*- coding: utf-8 -*-
"""
Created on Thu Apr  5 08:59:14 2018

@author: paprasad
"""



import os,re
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome("chromedriver.exe")

def create_csv(bug_urls,driver,ReportName):
    Bug_report = open(ReportName, 'a')
    for bug in bug_urls:
        driver.get(bug)
        id = bug.split('=')[1]
        product = driver.find_element_by_xpath("//*[@id='field_container_product']").text
        comp = driver.find_element_by_xpath("//*[@id='field_container_component']").text
        comp=re.sub(r"[\(\[].*?[\)\]]", "", comp)
        assignee = driver.find_element_by_xpath("//*[@id='bz_show_bug_column_1']/table/tbody/tr[13]/td/span/span").text
        status = driver.find_element_by_xpath("//*[@id='static_bug_status']").text
        resoltuion  = status.split(' ')[1]
        status = status.split(' ')[0]
        summary = str(driver.find_element_by_xpath("//*[@id='c0']/pre").text.encode("utf-8")).rstrip()
        summary = summary.replace("\r","")
        summary = summary.replace("\n","")
        temp = id+","+product+","+comp+","+assignee+","+status+","+resoltuion+","+summary+"\n"
        print (id,product,comp,assignee,status,resoltuion,summary)
        Bug_report.write(temp)
    Bug_report.close()
def crawler(url,driver,BugListFileName):
    #driver = webdriver.Chrome("chromedriver.exe")
    driver.get(url)
    bug_urls = []
    for a in driver.find_elements_by_xpath("//*[@id]/td[1]/a"):
        herf = a.get_attribute("href")
        bug_urls.append(herf)
    thefile = open(BugListFileName, 'w+')
    thefile.write("\n".join(bug_urls))
    thefile.close()
    #create_csv(bug_urls,driver)


def crawl_bug_list(driver,ListFileName,ReportName):
    driver = webdriver.Chrome("chromedriver.exe")
    f = open(ListFileName,'r')
    try:
        for bug in f:
            Bug_report = open(ReportName, 'a')
            driver.get(bug)
            id = bug.split('=')[1].rstrip()
            product = driver.find_element_by_xpath("//*[@id='field_container_product']").text
            comp = driver.find_element_by_xpath("//*[@id='field_container_component']").text
            comp=re.sub(r"[\(\[].*?[\)\]]", "", comp)
            assignee = driver.find_element_by_xpath("//*[@id='bz_show_bug_column_1']/table/tbody/tr[13]/td/span/span").text
            status = driver.find_element_by_xpath("//*[@id='static_bug_status']").text
            resoltuion  = status.split(' ')[1]
            status = status.split(' ')[0]
            summary = str(driver.find_element_by_xpath("//*[@id='c0']/pre").text.encode("utf-8")).rstrip()
            summary = summary.replace("\r","")
            summary = summary.replace("\n","")
            temp = id+"*pawan*"+product+"*pawan*"+comp+"*pawan*"+assignee+"*pawan*"+status+"*pawan*"+resoltuion+"*pawan*"+summary+"\n"
            print (id,product,comp,assignee,status,resoltuion,summary)
            Bug_report.write(temp)
    except:
        pass            
            
url = "https://bugs.eclipse.org/bugs/buglist.cgi?bug_status=ASSIGNED&limit=0&order=bug_id&query_format=advanced"  
BugListFileName = "Bug_Report_ASSIGNED.txt" 
crawler(url,driver,BugListFileName)
            